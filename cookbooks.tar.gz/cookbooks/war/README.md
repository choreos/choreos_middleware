Description
===========

This is a template to a WAR-install cookbook.

