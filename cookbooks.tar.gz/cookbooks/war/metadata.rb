maintainer       "CHOReOS"
maintainer_email "ccsl@ime.usp.br"
license          "MPL v2.0"
description      "Deploys a WAR file into a cloud node"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.1"

depends "apt"
depends "tomcat"

