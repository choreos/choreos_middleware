Description
====

This is a template to a cookbook that deploys a CHOReOS Coordination Delegate (CD) on an EasyESB node. 

The deployable CD artifact must be a tar.gz with the config.xml file and the lts and wsdl files.
All the three files must be in the root of the tar.gz, without any folder structure.

License and Author
====

Leonardo Leite
CCSL - Centro de Competencia de Software Livre - IME/USP
University of Sao Paulo
http://ccsl.ime.usp.br
License MPL v2.0

CHOReOS Project
http://choreos.eu/

