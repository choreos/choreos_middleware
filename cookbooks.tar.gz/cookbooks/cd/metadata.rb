description      "Deploys a CD on an EasyESB node"
license          "MPL v2.0"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
maintainer       "CCSL - Centro de Competencia de Software Livre - IME/USP"
maintainer_email "ccsl@ime.usp.br"
version          "0.0.1"

depends "easyesb"
