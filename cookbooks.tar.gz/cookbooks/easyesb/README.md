Description
====

This cookbook installs the Easy Enterprise Service Bus. 

More information about EasyESB at http://research.petalslink.org/display/easyesb

Requirements
====

Works on any platform with Java Sun SDK installed.


License and Author
====

Leonardo Leite
CCSL - Centro de Competencia de Software Livre - IME/USP
University of Sao Paulo
http://ccsl.ime.usp.br
MPL 2.0

CHOReOS Project
http://choreos.eu/

