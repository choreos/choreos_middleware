maintainer       "CHOReOS"
maintainer_email "tfurtado@ime.usp.br, lago@ime.usp.br"
license          "MPL v2.0"
description      "Deactivate a deployed JAR file running on a cloud node"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.1"

depends "service$NAME"

