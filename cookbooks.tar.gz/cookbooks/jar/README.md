Description
===========

This is a template to a JAR-install cookbook.

